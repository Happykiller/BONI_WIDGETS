angular.module('bonitasoft.ui.widgets')
  .directive('customTraceError', function() {
    return {
      controllerAs: 'ctrl',
      controller: function ($scope, $log, widgetNameFactory, $document) {
    $scope.filterDoublon = function(requireds){
        var tabReturn = [];
        var old = null;
        for(var indice in requireds){
            var item = requireds[indice];
            if((old !== null) && (item.$name === old)){
                //skip
            }else{
                old = item.$name;
                tabReturn.push(item);
            }
        }
        
        return tabReturn;
    }
    
    $scope.$watch(angular.bind(this, function () {
        $scope.myErrors = $scope.filterDoublon($scope.properties.value.$error.required);
    }), function (newVal, oldVal) {
        // now we will pickup changes to newVal and oldVal
    });
    
    $scope.getLabel = function(key){
        var strlabel = "prout";
        var selector = document.getElementsByName(key)[0].parentNode.parentNode;
        var label = selector.querySelector('label');
        if(label === null){
            //DatePicker
            selector = selector.parentNode;
            label = selector.querySelector('label');
            if(label.classList.contains('control-label')){
                strlabel = label.innerHTML;
            }
        }else if(label.classList.contains('control-label')){
            strlabel = label.innerHTML;
        } else if(selector.classList.contains('checkbox')){
            //checkbox
            strlabel = label.textContent;
        }else if(selector.classList.contains('radio')){
            //radio
            selector = selector.parentNode.parentNode;
            label = selector.querySelector('label');
            strlabel = label.innerHTML;
        }
        return strlabel;
    }
},
      template: '<div class="alert alert-danger" ng-show="properties.value.$invalid">\n    <div ng-repeat="(index, value) in myErrors">\n            <ul>\n                <li>Widget en erreur : <b>{{getLabel(value.$name)}}</b>\n                    <ul>\n                        <li ng-if=\'(value.$viewValue !== null) && (value.$viewValue !== "")\'>Mauvaise valeur : {{value.$viewValue}}</li>\n                    </ul>\n                </li>\n            </ul>\n    <div>\n</div>'
    };
  });
