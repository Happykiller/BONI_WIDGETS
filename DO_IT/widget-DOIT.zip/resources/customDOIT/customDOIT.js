angular.module('bonitasoft.ui.widgets')
  .directive('customDOIT', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbButtonCtrl($scope, $http, $timeout, $location, $log, $window) {

  'use strict';

  this.action = function action() {
    $http({
      method: 'PUT',
      data: {assigned_id: $scope.properties.userId},
      url: "../API/bpm/humanTask/"+$scope.properties.taskId
    }).then(function successCallback(response) {
        if(response.status === 200){
            $window.top.location.assign('/bonita/portal/form/taskInstance/'+$scope.properties.taskId);
        }else{
            $log.error(response.statusText)
        }
    });
  }
},
      template: '<div class="text-{{ properties.alignment }}">\n    <button\n        ng-class="\'btn btn-\' + properties.buttonStyle"\n        ng-click="ctrl.action()"\n        type="button">{{ properties.text | uiTranslate }}</button>\n</div>\n'
    };
  });
