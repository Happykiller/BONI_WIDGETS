(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customAutocomplete', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbAutocompleteCtrl($scope, $parse, $log, widgetNameFactory, $filter) {

  'use strict';
  
  this.name = widgetNameFactory.getName('pbAutocomplete');
  
  var that = this;
  var bonitaLib = new BonitaLib();
  
  $scope.listTrad = [];
  
  var tmpListDatas = [];
  for(var index in $scope.properties.availableValues){
      var elt = angular.copy($scope.properties.availableValues[index]);
      elt[$scope.properties.displayedKey+"_trad"] = $filter('uiTranslate')(elt[$scope.properties.displayedKey]);
      tmpListDatas.push(elt);
  }
  
  $scope.listTrad = bonitaLib.order({
    collection: tmpListDatas,
    compare: function(elt1, elt2){
            if(elt1[$scope.properties.displayedKey+"_trad"] > elt2[$scope.properties.displayedKey+"_trad"]){
                return 1;
            }else if(elt1[$scope.properties.displayedKey+"_trad"] < elt2[$scope.properties.displayedKey+"_trad"]){
                return -1;
            }else{
                return 0;
            }
        }
    });
    
    $scope.$watch(angular.bind(this, function () {
        if($scope.valueTmp !== undefined){
            $scope.properties.value = $scope.valueTmp[$scope.properties.displayedKey];
        }else{
            $scope.properties.value = undefined;
        }
        if(($scope.properties.value === undefined) && ($scope.properties.required)){
            $scope.$form[that.name].$setValidity("noSelectedValue", false);
        }else{
            $scope.$form[that.name].$setValidity("noSelectedValue", true);
        }
    }), function (newVal, oldVal) {
        // now we will pickup changes to newVal and oldVal
    });

  function createGetter(accessor) {
    return accessor && $parse(accessor);
  }

  this.getLabel = createGetter($scope.properties.displayedKey) || function (item) {
    return typeof item === 'string' ? item : JSON.stringify(item);
  };
  
  $scope.customFilter = function(index, viewValue) {
      try{
            var elt = $scope.listTrad[index-1];
            var eltTrad = elt[$scope.properties.displayedKey+"_trad"];
            var tradWithNoAccent = bonitaLib.removeDiacritics({str:eltTrad});
            var stratTradWithNoAccentLowCase = tradWithNoAccent.substr(0, viewValue.length).toLowerCase();
            var viewValueLowCase = viewValue.toLowerCase();
            if(viewValueLowCase === stratTradWithNoAccentLowCase){
            return true;
            }else{
            return false;
            }
      }catch(e){
          return false;
      }
  }

  if (!$scope.properties.isBound('value')) {
    $log.error('the pbAutocomplete property named "value" need to be bound to a variable');
  }
}
,
      template: '<div ng-class="{\n    \'form-horizontal\': properties.labelPosition === \'left\' && !properties.labelHidden,\n    \'row\': properties.labelPosition === \'top\' && !properties.labelHidden || properties.labelHidden\n    }">\n    <div class="form-group">\n        <label\n            ng-if="!properties.labelHidden"\n            ng-class="{ \'control-label--required\': properties.required }"\n            class="control-label col-xs-{{ !properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 12 }}">\n            {{ properties.label | uiTranslate }}\n        </label>\n        <div class="col-xs-{{ 12 - (!properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 0) }}" >\n            <input\n                type="text"\n                class="form-control"\n                placeholder="{{ properties.placeholder | uiTranslate }}"\n                typeahead-append-to-body="true"\n                typeahead="item as (ctrl.getLabel(item) | uiTranslate) for item in listTrad | filter:$viewValue:customFilter | limitTo : properties.numrow"\n                typeahead-template-url="customTypeaheadForInputAutocomplete.html"\n                ng-model="valueTmp"\n                ng-model-options="{ debounce: properties.delay }"\n                name="{{ctrl.name}}"\n                ng-required="properties.required"\n                ng-readonly="properties.readOnly">\n\n            <div ng-messages="$form[ctrl.name].$error" class="text-danger" role="alert">\n                <div ng-message="noSelectedValue">{{"Please select a choice in the sudgest list." | uiTranslate}}</div>\n            </div>\n\n            <!-- It doesn\'t work if we put it inside form.html -->\n            <script type="text/ng-template" id="customTypeaheadForInputAutocomplete.html">\n                <a  bind-html-unsafe="match.label | typeaheadHighlight:query"></a>\n            </script>\n        </div>\n    </div>\n</div>\n'
    };
  });
